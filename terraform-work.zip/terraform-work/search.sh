#!/bin/sh
find . -mindepth 4 -maxdepth 4 -not -empty -type d
