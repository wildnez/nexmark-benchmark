#!/usr/bin/python3

import json
import subprocess
import os
import shutil


output = subprocess.check_output(f'/Users/rahul/terraform output -json nodes_public_ips', shell=True, text=True)
data = json.loads(output)

if os.path.exists("results"):
   shutil.rmtree('results')     
os.mkdir("results")


for ip in data:
    os.mkdir(f"results/{ip}")
    output =  subprocess.check_output(f"scp -r -i key -o StrictHostKeyChecking=no  ubuntu@{ip}:benchmark-results results/{ip}", shell=True, text=True)
    print(output)

